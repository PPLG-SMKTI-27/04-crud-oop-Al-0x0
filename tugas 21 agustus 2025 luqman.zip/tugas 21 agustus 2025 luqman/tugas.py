# Daftar buku 
buku_list = []

def tambah_buku():
    id_buku = input("ID buku: ")
    judul = input("Judul: ")
    penulis = input("Penulis: ")
    tahun = input("Tahun: ")
    buku_list.append((id_buku, judul, penulis, tahun))
    print("Buku ditambahkan!\n")

def lihat_buku():
    if not buku_list:
        print("Belum ada buku.\n")
    else:
        print("Daftar Buku:")
        for id_buku, judul, penulis, tahun in buku_list:
            print(f"{id_buku}. {judul} - {penulis} ({tahun})")
        print()

def hapus_buku():
    id_buku = input("ID buku yang mau dihapus: ")
    for buku in buku_list:
        if buku[0] == id_buku:
            buku_list.remove(buku)
            print("Buku dihapus!\n")
            return
    print("ID tidak ditemukan.\n")

def main():
    while True:
        print("=== MENU ===")
        print("1. Tambah buku")
        print("2. Lihat buku")
        print("3. Hapus buku")
        print("4. Keluar")
        pilihan = input("Pilih: ")
        print()
        if pilihan == "1":
            tambah_buku()
        elif pilihan == "2":
            lihat_buku()
        elif pilihan == "3":
            hapus_buku()
        elif pilihan == "4":
            print("Bye!")
            break
        else:
            print("Pilihan nggak ngerti, coba lagi.\n")

if __name__ == "__main__":
    main()
